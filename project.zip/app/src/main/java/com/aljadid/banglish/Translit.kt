package com.aljadid.banglish

/** বাংলা → বাংলিশ (রোমান): শব্দ-তালিকা + স্বরলোপ (schwa deletion) নিয়ম */
object Translit {
    private val cons = mapOf(
        'ক' to "k", 'খ' to "kh", 'গ' to "g", 'ঘ' to "gh", 'ঙ' to "ng",
        'চ' to "ch", 'ছ' to "chh", 'জ' to "j", 'ঝ' to "jh", 'ঞ' to "n",
        'ট' to "t", 'ঠ' to "th", 'ড' to "d", 'ঢ' to "dh", 'ণ' to "n",
        'ত' to "t", 'থ' to "th", 'দ' to "d", 'ধ' to "dh", 'ন' to "n",
        'প' to "p", 'ফ' to "f", 'ব' to "b", 'ভ' to "bh", 'ম' to "m",
        'য' to "j", 'র' to "r", 'ল' to "l", 'শ' to "sh", 'ষ' to "sh",
        'স' to "s", 'হ' to "h",
        '\u09DC' to "r", '\u09DD' to "rh", '\u09DF' to "y"
    )
    private val vowels = mapOf(
        'অ' to "o", 'আ' to "a", 'ই' to "i", 'ঈ' to "i", 'উ' to "u", 'ঊ' to "u",
        'ঋ' to "ri", 'এ' to "e", 'ঐ' to "oi", 'ও' to "o", 'ঔ' to "ou"
    )
    private val kars = mapOf(
        'া' to "a", 'ি' to "i", 'ী' to "i", 'ু' to "u", 'ূ' to "u",
        'ৃ' to "ri", 'ে' to "e", 'ৈ' to "oi", 'ো' to "o", 'ৌ' to "ou"
    )
    private val others = mapOf(
        'ৎ' to "t", 'ং' to "ng", 'ঃ' to "h", 'ঁ' to "n", '।' to "."
    )
    private const val DIGITS = "০১২৩৪৫৬৭৮৯"

    /** সাধারণ শব্দের সঠিক বাংলিশ বানান */
    private val dict = mapOf(
        "আমি" to "ami", "তুমি" to "tumi", "সে" to "se", "আপনি" to "apni",
        "আমরা" to "amra", "তোমরা" to "tomra", "তারা" to "tara", "তুই" to "tui",
        "কি" to "ki", "কী" to "ki", "কেন" to "keno", "কেমন" to "kemon",
        "ভাল" to "bhalo", "ভালো" to "bhalo", "ভালোবাসা" to "bhalobasha",
        "না" to "na", "নাই" to "nai", "নেই" to "nei",
        "হ্যাঁ" to "hya", "হ্যালো" to "hello", "ঠিক" to "thik",
        "আছে" to "ache", "আছি" to "achi", "আছো" to "acho", "ছিল" to "chhilo",
        "ধন্যবাদ" to "dhonnobad", "জন্য" to "jonno", "কত" to "koto",
        "অনেক" to "onek", "একটু" to "ektu", "এবং" to "ebong", "কিন্তু" to "kintu",
        "তবে" to "tobe", "যদি" to "jodi", "তাহলে" to "tahole",
        "যাই" to "jai", "যাব" to "jabo", "যাবো" to "jabo",
        "আসি" to "ashi", "আসব" to "ashbo", "আসবো" to "ashbo",
        "কোনো" to "kono", "কোন" to "kon", "এখানে" to "ekhane", "ওখানে" to "okhane",
        "কোথায়" to "kothay", "ভাই" to "bhai", "আপু" to "apu", "বন্ধু" to "bondhu",
        "আল্লাহ" to "allah", "ইনশাআল্লাহ" to "inshaallah", "মাশাআল্লাহ" to "mashaallah",
        "সালাম" to "salam", "আসসালামু" to "assalamu", "আলাইকুম" to "alaikum",
        "বাংলাদেশ" to "bangladesh", "ঢাকা" to "dhaka", "টাকা" to "taka",
        "পাঞ্জাবী" to "panjabi", "পাঞ্জাবি" to "panjabi", "জুব্বা" to "jubba",
        "পায়জামা" to "payjama", "সেলুয়ার" to "selowar", "কাবলী" to "kabli",
        "ফতোয়া" to "fotoa", "মাপ" to "map", "অর্ডার" to "order"
    )

    fun digit(c: Char): String? {
        val i = DIGITS.indexOf(c)
        return if (i >= 0) i.toString() else null
    }

    private fun isCons(c: Char?) = c != null && cons.containsKey(c)
    private fun isKar(c: Char?) = c != null && kars.containsKey(c)

    fun convert(s: String): String {
        dict[s]?.let { return it }
        val sb = StringBuilder()
        for (i in s.indices) {
            val c = s[i]
            val prev = s.getOrNull(i - 1)
            val next = s.getOrNull(i + 1)
            when {
                c == '্' -> {}
                c == 'য' && prev == '্' -> {
                    sb.append("y")
                    // ব্যবহার → byabohar : য-ফলার পর ব্যঞ্জন থাকলে 'a' বসে
                    if (isCons(next)) sb.append("a")
                }
                cons.containsKey(c) -> {
                    sb.append(cons[c])
                    // শব্দের শেষে, কার বা হসন্তের আগে 'o' বসে না
                    if (next != null && next != '্' && !isKar(next)) {
                        // স্বরলোপ: মাঝের ব্যঞ্জনের পরের ব্যঞ্জনে কার থাকলে 'o' পড়ে যায় (করছি → korchhi)
                        val deleted = i > 0 && isCons(next) && isKar(s.getOrNull(i + 2))
                        if (!deleted) sb.append("o")
                    }
                }
                vowels.containsKey(c) -> sb.append(vowels[c])
                kars.containsKey(c) -> sb.append(kars[c])
                others.containsKey(c) -> sb.append(others[c])
                digit(c) != null -> sb.append(digit(c))
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }
}
