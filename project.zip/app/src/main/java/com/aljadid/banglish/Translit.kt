package com.aljadid.banglish

/** বাংলা → বাংলিশ (রোমান) রূপান্তর */
object Translit {
    private val cons = mapOf(
        'ক' to "k", 'খ' to "kh", 'গ' to "g", 'ঘ' to "gh", 'ঙ' to "ng",
        'চ' to "ch", 'ছ' to "chh", 'জ' to "j", 'ঝ' to "jh", 'ঞ' to "n",
        'ট' to "t", 'ঠ' to "th", 'ড' to "d", 'ঢ' to "dh", 'ণ' to "n",
        'ত' to "t", 'থ' to "th", 'দ' to "d", 'ধ' to "dh", 'ন' to "n",
        'প' to "p", 'ফ' to "ph", 'ব' to "b", 'ভ' to "bh", 'ম' to "m",
        'য' to "j", 'র' to "r", 'ল' to "l", 'শ' to "sh", 'ষ' to "sh",
        'স' to "s", 'হ' to "h",
        '\u09DC' to "r", '\u09DD' to "rh", '\u09DF' to "y"
    )
    private val vowels = mapOf(
        'অ' to "o", 'আ' to "a", 'ই' to "i", 'ঈ' to "i", 'উ' to "u", 'ঊ' to "u",
        'ঋ' to "ri", 'এ' to "e", 'ঐ' to "oi", 'ও' to "o", 'ঔ' to "ou"
    )
    private val kars = mapOf(
        'া' to "a", 'ি' to "i", 'ী' to "i", 'ু' to "u", 'ূ' to "u",
        'ৃ' to "ri", 'ে' to "e", 'ৈ' to "oi", 'ো' to "o", 'ৌ' to "ou"
    )
    private val others = mapOf(
        'ৎ' to "t", 'ং' to "ng", 'ঃ' to "h", 'ঁ' to "n", '।' to "."
    )
    private val digits = "০১২৩৪৫৬৭৮৯"

    fun digit(c: Char): String? {
        val i = digits.indexOf(c)
        return if (i >= 0) i.toString() else null
    }

    fun convert(s: String): String {
        val sb = StringBuilder()
        for (i in s.indices) {
            val c = s[i]
            val prev = s.getOrNull(i - 1)
            val next = s.getOrNull(i + 1)
            when {
                c == '্' -> {}
                c == 'য' && prev == '্' -> sb.append("y")
                cons.containsKey(c) -> {
                    sb.append(cons[c])
                    // শব্দের শেষে বা কার/হসন্তের আগে 'o' বসবে না
                    if (next != null && next != '্' && !kars.containsKey(next)) sb.append("o")
                }
                vowels.containsKey(c) -> sb.append(vowels[c])
                kars.containsKey(c) -> sb.append(kars[c])
                others.containsKey(c) -> sb.append(others[c])
                digit(c) != null -> sb.append(digit(c))
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }
}
