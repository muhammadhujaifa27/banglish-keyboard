package com.aljadid.banglish

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        layout.addView(TextView(this).apply {
            text = "Banglish Keyboard\n\nপ্রভাত লেআউটে বাংলা টাইপ করলে বাংলিশ লেখা হবে।\nযেমন: আমি ভাত খাই → ami bhat khai"
            textSize = 18f
        })
        layout.addView(Button(this).apply {
            text = "১. কিবোর্ড চালু করুন"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "২. কিবোর্ড বেছে নিন"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })

        layout.addView(Button(this).apply {
            text = "🤖 বাংলিশ বট খুলুন"
            setOnClickListener { startActivity(Intent(this@MainActivity, BotActivity::class.java)) }
        })
        layout.addView(TextView(this).apply {
            text = "\n✨ AI বাটন (ঐচ্ছিক, ইন্টারনেট লাগবে)\nAnthropic API key দিলে কিবোর্ডের ✨ AI বাটন পুরো লেখাটাকে নিখুঁত বাংলিশে রূপান্তর করবে। key না দিলেও কিবোর্ড স্বাভাবিক চলবে।"
            textSize = 15f
        })
        val keyBox = EditText(this).apply {
            hint = "API key (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("api_key", ""))
        }
        val modelBox = EditText(this).apply {
            hint = "মডেল"
            setText(prefs.getString("model", "claude-haiku-5-5"))
        }
        val gKeyBox = EditText(this).apply {
            hint = "Gemini API key (ফ্রি, aistudio.google.com)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("gemini_key", ""))
        }
        val gModelBox = EditText(this).apply {
            hint = "Gemini মডেল"
            setText(prefs.getString("gemini_model", "gemini-flash-latest"))
        }
        layout.addView(TextView(this).apply {
            text = "\nফ্রি অপশন: Google Gemini (দিলে এটাই আগে ব্যবহার হবে)"
            textSize = 15f
        })
        layout.addView(gKeyBox)
        layout.addView(gModelBox)
        layout.addView(TextView(this).apply {
            text = "\nঅথবা Claude (পেইড)"
            textSize = 15f
        })
        layout.addView(keyBox)
        layout.addView(modelBox)
        layout.addView(TextView(this).apply {
            text = "\nচেপে ধরে ছোট অক্ষর লেখার সময় (মিলিসেকেন্ড, ১০০০ = ১ সেকেন্ড)"
            textSize = 15f
        })
        val longBox = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("long_ms", 600).toString())
        }
        layout.addView(longBox)
        layout.addView(Button(this).apply {
            text = "সেভ করুন"
            setOnClickListener {
                prefs.edit()
                    .putString("api_key", keyBox.text.toString().trim())
                    .putString("gemini_key", gKeyBox.text.toString().trim())
                    .putString("gemini_model", gModelBox.text.toString().trim().ifEmpty { "gemini-flash-latest" })
                    .putString("model", modelBox.text.toString().trim().ifEmpty { "claude-haiku-5-5" })
                    .putInt("long_ms", (longBox.text.toString().toIntOrNull() ?: 600).coerceIn(200, 2000))
                    .apply()
                Toast.makeText(this@MainActivity, "সেভ হয়েছে", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(EditText(this).apply { hint = "এখানে টাইপ করে টেস্ট করুন" })
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
