package com.aljadid.banglish

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        layout.addView(TextView(this).apply {
            text = "Banglish Keyboard\n\nবাংলা কী চাপলে বাংলিশ (রোমান) লেখা হবে।\nযেমন: আমি ভাত খাই → ami bhat khai"
            textSize = 18f
        })
        layout.addView(Button(this).apply {
            text = "১. কিবোর্ড চালু করুন"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "২. কিবোর্ড বেছে নিন"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })
        layout.addView(EditText(this).apply { hint = "এখানে টাইপ করে টেস্ট করুন" })
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
