package com.aljadid.banglish

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** বাংলিশ বট: বাংলা লিখলে বাংলিশে লিখে দেয় */
class BotActivity : Activity() {

    private lateinit var feed: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: Button
    private lateinit var hint: TextView
    private var busy = false
    private val ui = Handler(Looper.getMainLooper())

    private val ink = 0xFF13201B.toInt()
    private val muted = 0xFF5B6B64.toInt()
    private val green = 0xFF006A4E.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int, stroke: Int? = null): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        if (stroke != null) g.setStroke(dp(1), stroke)
        return g
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFFF4F7F5.toInt())

        // হেডার
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(16), dp(10), dp(12), dp(10))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val title = TextView(this)
        title.text = "বাংলিশ বট"
        title.textSize = 22f
        title.setTextColor(ink)
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        val sub = TextView(this)
        sub.text = "বাংলায় লিখুন, বাংলিশে পান।"
        sub.textSize = 13f
        sub.setTextColor(muted)
        titles.addView(title)
        titles.addView(sub)
        header.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val clear = Button(this)
        clear.text = "নতুন চ্যাট"
        clear.setOnClickListener {
            if (!busy) {
                feed.removeAllViews()
                feed.addView(hint)
            }
        }
        header.addView(clear)
        root.addView(header)

        // চ্যাট
        feed = LinearLayout(this)
        feed.orientation = LinearLayout.VERTICAL
        feed.setPadding(dp(14), dp(6), dp(14), dp(14))
        hint = TextView(this)
        hint.text = "নিচের ঘরে বাংলা লিখে পাঠান। বট সেটাকে ঠিকঠাক বাংলিশে বদলে দেবে।\n\nযেমন: আমি আজ দোকানে যাবো না।"
        hint.textSize = 16f
        hint.setTextColor(muted)
        hint.setPadding(0, dp(20), 0, 0)
        feed.addView(hint)
        scroll = ScrollView(this)
        scroll.addView(feed)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // ইনপুট
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.BOTTOM
        bar.setPadding(dp(10), dp(8), dp(10), dp(10))
        input = EditText(this)
        input.hint = "এখানে বাংলায় লিখুন…"
        input.textSize = 17f
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        input.minLines = 1
        input.maxLines = 5
        input.background = shape(Color.WHITE, 14, 0xFFD5DFDA.toInt())
        input.setPadding(dp(12), dp(10), dp(12), dp(10))
        bar.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sendBtn = Button(this)
        sendBtn.text = "পাঠান"
        sendBtn.setOnClickListener { send() }
        bar.addView(sendBtn)
        root.addView(bar)

        setContentView(root)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun addUser(src: String) {
        val t = TextView(this)
        t.text = src
        t.textSize = 16f
        t.setTextColor(ink)
        t.setPadding(dp(12), dp(8), dp(12), dp(8))
        t.background = shape(0xFFDFF0E8.toInt(), 14)
        t.maxWidth = (resources.displayMetrics.widthPixels * 0.85).toInt()
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.END
        lp.setMargins(dp(40), dp(8), 0, dp(6))
        feed.addView(t, lp)
    }

    private fun addBot(src: String) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(14), dp(12), dp(14), dp(8))
        card.background = shape(Color.WHITE, 14, 0xFFD5DFDA.toInt())
        val out = TextView(this)
        out.textSize = 19f
        out.setTextIsSelectable(true)
        card.addView(out)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val copy = Button(this)
        copy.text = "কপি করুন"
        val again = Button(this)
        again.text = "আবার করুন"
        row.addView(copy)
        row.addView(again)
        card.addView(row)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(4), 0, dp(6))
        feed.addView(card, lp)

        copy.setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("banglish", out.text.toString()))
            toast("কপি হয়েছে ✓")
        }
        again.setOnClickListener { if (!busy) run(src, out, copy, again) }
        run(src, out, copy, again)
    }

    private fun send() {
        val src = input.text.toString().trim()
        if (src.isEmpty() || busy) return
        if (!AiClient.hasKey(this)) {
            toast("আগে অ্যাপের মূল পেজে গিয়ে Gemini key দিন")
            return
        }
        input.setText("")
        if (hint.parent != null) feed.removeView(hint)
        addUser(src)
        addBot(src)
    }

    private fun run(src: String, out: TextView, copy: Button, again: Button) {
        busy = true
        sendBtn.isEnabled = false
        copy.isEnabled = false
        again.isEnabled = false
        out.setTextColor(muted)
        out.text = "ভাবছি…"
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        Thread {
            var result: String? = null
            var err: String? = null
            try {
                result = AiClient.convert(this, src)
            } catch (e: Exception) {
                err = e.message ?: "অজানা ত্রুটি"
            }
            ui.post {
                val r = result
                busy = false
                sendBtn.isEnabled = true
                again.isEnabled = true
                if (r != null && r.isNotBlank()) {
                    out.setTextColor(ink)
                    out.text = r
                    copy.isEnabled = true
                } else {
                    out.setTextColor(0xFFB3261E.toInt())
                    out.text = "ত্রুটি: " + (err ?: "কোনো উত্তর আসেনি")
                }
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }.start()
    }
}
