package com.aljadid.banglish

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

class BanglishIME : InputMethodService() {

    private enum class Page { EN, BN_CONS, BN_VOWEL, SYM }

    private var page = Page.EN
    private var lastLetterPage = Page.EN
    private var shift = false
    private var banglish = true          // বাংলা → বাংলিশ কনভার্ট চালু/বন্ধ
    private val word = StringBuilder()   // চলমান বাংলা শব্দ
    private lateinit var root: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private val repeater = object : Runnable {
        override fun run() { backspace(); handler.postDelayed(this, 60) }
    }

    // ---------- লেআউট ----------
    private val enRows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val bnRows = listOf("কখগঘঙচছজঝঞ", "টঠডঢণতথদধন", "পফবভমযরলশষ")
    private val bnRow4 = listOf("স", "হ", "\u09DC", "\u09DD", "\u09DF")
    private val bnV1 = "অআইঈউঊঋএঐও"
    private val bnV2 = "ঔািীুূৃেৈো"
    private val bnV3 = listOf("ৌ", "্", "ঁ", "ং", "ঃ", "ৎ")
    private val symRows = listOf("@#\$_&-+()/", "*\"':;!?~|\\", "=%[]{}<>^`")
    private val bnDigits = "১২৩৪৫৬৭৮৯০"
    private val enDigits = "1234567890"

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFE8EAED.toInt())
            setPadding(dp(3), dp(4), dp(3), dp(6))
        }
        render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        word.clear()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        flush()
        super.onFinishInputView(finishingInput)
    }

    // ---------- UI তৈরি ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun key(
        label: String, weight: Float = 1f, fn: Boolean = false,
        active: Boolean = false, onTap: () -> Unit
    ): TextView {
        val t = TextView(this)
        t.text = label
        t.gravity = Gravity.CENTER
        t.textSize = if (label.length > 2) 14f else 20f
        t.setTextColor(Color.BLACK)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(8).toFloat()
        bg.setColor(
            when {
                active -> 0xFF9CC2FF.toInt()
                fn -> 0xFFC5C9D1.toInt()
                else -> Color.WHITE
            }
        )
        t.background = bg
        val lp = LinearLayout.LayoutParams(0, dp(50), weight)
        lp.setMargins(dp(2), dp(3), dp(2), dp(3))
        t.layoutParams = lp
        t.setOnClickListener { onTap() }
        return t
    }

    private fun backspaceKey(weight: Float): TextView {
        val t = key("⌫", weight, fn = true) {}
        t.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    backspace()
                    handler.postDelayed(repeater, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    handler.removeCallbacks(repeater)
            }
            true
        }
        return t
    }

    private fun spacer(weight: Float): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(0, dp(50), weight)
        return v
    }

    private fun row(views: List<View>): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        views.forEach { r.addView(it) }
        return r
    }

    private fun render() {
        root.removeAllViews()
        when (page) {
            Page.EN -> {
                root.addView(row(enDigits.map { c -> key("$c") { typeText("$c") } }))
                root.addView(row(enRows[0].map { c -> enKey(c) }))
                root.addView(row(listOf(spacer(0.5f)) + enRows[1].map { c -> enKey(c) } + spacer(0.5f)))
                root.addView(
                    row(
                        listOf(key("⇧", 1.5f, fn = true, active = shift) { shift = !shift; render() }) +
                            enRows[2].map { c -> enKey(c) } + backspaceKey(1.5f)
                    )
                )
            }
            Page.BN_CONS -> {
                root.addView(row(bnDigits.map { c -> key("$c") { typeDigit(c) } }))
                bnRows.forEach { r -> root.addView(row(r.map { c -> bnKey("$c") })) }
                root.addView(
                    row(
                        listOf(key("স্বর", 1.5f, fn = true) { page = Page.BN_VOWEL; render() }) +
                            bnRow4.map { c -> bnKey(c) } + backspaceKey(1.5f)
                    )
                )
            }
            Page.BN_VOWEL -> {
                root.addView(row(bnDigits.map { c -> key("$c") { typeDigit(c) } }))
                root.addView(row(bnV1.map { c -> bnKey("$c") }))
                root.addView(row(bnV2.map { c -> bnKey("$c") }))
                root.addView(
                    row(
                        listOf(key("ব্যঞ্জন", 1.5f, fn = true) { page = Page.BN_CONS; render() }) +
                            bnV3.map { c -> bnKey(c) } + backspaceKey(1.5f)
                    )
                )
            }
            Page.SYM -> {
                root.addView(row(enDigits.map { c -> key("$c") { typeText("$c") } }))
                symRows.forEach { r -> root.addView(row(r.map { c -> key("$c") { typeText("$c") } })) }
                root.addView(row(listOf(spacer(8.5f), backspaceKey(1.5f))))
            }
        }
        root.addView(bottomRow())
    }

    private fun enKey(c: Char): TextView {
        val s = if (shift) c.uppercaseChar().toString() else c.toString()
        return key(s) {
            typeText(s)
            if (shift) { shift = false; render() }
        }
    }

    private fun bnKey(s: String) = key(s) { typeBangla(s) }

    private fun bottomRow(): LinearLayout {
        val isBn = page == Page.BN_CONS || page == Page.BN_VOWEL ||
            (page == Page.SYM && lastLetterPage != Page.EN)
        return row(
            listOf(
                key(if (page == Page.SYM) "ABC" else "?123", 1.3f, fn = true) {
                    flush()
                    if (page == Page.SYM) page = lastLetterPage
                    else { lastLetterPage = page; page = Page.SYM }
                    render()
                },
                key(if (isBn) "EN" else "বাং", 1.1f, fn = true) {
                    flush()
                    page = if (isBn) Page.EN else Page.BN_CONS
                    lastLetterPage = page
                    render()
                },
                key(if (banglish) "বা→ba" else "বা", 1.4f, fn = true, active = banglish) {
                    flush(); banglish = !banglish; render()
                },
                key(if (isBn) "বাংলা" else "English", 3.5f) { space() },
                key(".", 1f) { typeText(".") },
                key("⏎", 1.3f, fn = true) { enter() }
            )
        )
    }

    // ---------- ইনপুট লজিক ----------
    private fun flush() {
        if (word.isNotEmpty()) {
            currentInputConnection?.commitText(Translit.convert(word.toString()), 1)
            word.clear()
        }
    }

    private fun typeBangla(s: String) {
        if (banglish) {
            word.append(s)
            currentInputConnection?.setComposingText(Translit.convert(word.toString()), 1)
        } else {
            currentInputConnection?.commitText(s, 1)
        }
    }

    private fun typeDigit(c: Char) {
        flush()
        val d = if (banglish) (Translit.digit(c) ?: "$c") else "$c"
        currentInputConnection?.commitText(d, 1)
    }

    private fun typeText(s: String) {
        flush()
        currentInputConnection?.commitText(s, 1)
    }

    private fun space() {
        flush()
        currentInputConnection?.commitText(" ", 1)
    }

    private fun enter() {
        flush()
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noEnter = ((ei?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (ei == null || noEnter || action == EditorInfo.IME_ACTION_NONE ||
            action == EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            currentInputConnection?.performEditorAction(action)
        }
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        if (word.isNotEmpty()) {
            word.deleteCharAt(word.length - 1)
            if (word.isEmpty()) {
                ic.setComposingText("", 1)
                ic.finishComposingText()
            } else {
                ic.setComposingText(Translit.convert(word.toString()), 1)
            }
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
    }
}
